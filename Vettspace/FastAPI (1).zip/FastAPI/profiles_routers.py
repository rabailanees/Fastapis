from fastapi import FastAPI, Depends, APIRouter, HTTPException
import models, schemas, database
from sqlalchemy.orm import Session
from typing import List


app = FastAPI()


router= APIRouter(
    prefix="/profile",
    tags=['Profile']
)


def get_profiles(db: Session = Depends(database.get_db)):
    profiles = db.query(models.ProfileModel).all()
    return profiles


def create_profile(profile: schemas.ProfileSchema, db: Session = Depends(database.get_db)):
    new_profile = models.ProfileModel(
        id=profile.id,
        name=profile.name,
        profession=profile.profession,
        email_address=profile.email_address,
    )
    db.add(new_profile)
    db.commit()
    db.refresh(new_profile)
    return new_profile


@router.get('/', response_model=List[schemas.ProfileSchema])
def get_profiles(db: Session = Depends(database.get_db)):
    profiles = db.query(models.ProfileModel).all()
    return profiles


@router.post('/', response_model=schemas.ProfileSchema)
def create_profile(profile: schemas.ProfileSchema, db: Session = Depends(database.get_db)):
    # check if email address already exists
    existing_profile = db.query(models.ProfileModel).filter(models.ProfileModel.email_address == profile.email_address).first()
    if existing_profile:
        raise HTTPException(status_code=400, detail="Email address already exists")
    new_profile = models.ProfileModel(
        name=profile.name,
        profession=profile.profession,
        email_address=profile.email_address,
    )
    db.add(new_profile)
    db.commit()
    db.refresh(new_profile)
    return new_profile