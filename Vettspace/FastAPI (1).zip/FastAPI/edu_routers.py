from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from fastapi import FastAPI, Depends
import models, schemas, database

app = FastAPI()

router = APIRouter(
    prefix="/education",
    tags=['Education']
)

def get_education(db: Session = Depends(database.get_db)):
    educations = db.query(models.EducationModel).all()
    return educations


def create_education(education: schemas.Education, db: Session = Depends(database.get_db)):
    new_education = models.EducationModel(
        id=education.id,
        title=education.title,
        degree=education.degree,
        institute=education.institute,
        year=education.year,
        profile_id=education.profile_id  
    )
    db.add(new_education)
    db.commit()
    db.refresh(new_education)
    return new_education


@router.get('/',response_model=List[schemas.Education])
def get_education(db: Session = Depends(database.get_db)):
    education = db.query(models.EducationModel).all()
    return education


@router.post('/', response_model=schemas.Education)
def create_education(education: schemas.Education, db: Session = Depends(database.get_db)):
    new_education = models.EducationModel(
        title=education.title,
        degree=education.degree,
        institute=education.institute,
        year=education.year,
        profile_id=education.profile_id  
    )
    db.add(new_education)
    db.commit()
    db.refresh(new_education)
    return new_education