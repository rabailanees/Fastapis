from fastapi import FastAPI, Depends, APIRouter
import models, schemas, database
from sqlalchemy.orm import Session
from typing import List

app = FastAPI()

router = APIRouter(
    prefix="/sociallinks",
    tags=['Social Links']
)


def get_social_links(db: Session = Depends(database.get_db)):
    social_links = db.query(models.SocialLinksModel).all()
    return social_links


def create_social_links(social_links: schemas.SocialLinks, db: Session = Depends(database.get_db)):
    new_social_link = models.SocialLinksModel(
        id=social_links.id,
        facebook=social_links.facebook,
        instagram=social_links.instagram,
        linkedIn=social_links.linkedIn,
        dribble=social_links.dribble,
        profile_id=social_links.profile_id
    )
    db.add(new_social_link)
    db.commit()
    db.refresh(new_social_link)
    return new_social_link

@router.get('/', response_model=List[schemas.SocialLinks])
def get_social_links(db: Session = Depends(database.get_db)):
    social_links = db.query(models.SocialLinksModel).all()
    return social_links

@router.post('/', response_model=schemas.SocialLinks)
def create_social_links(social_links: schemas.SocialLinks, db: Session = Depends(database.get_db)):
    new_social_link = models.SocialLinksModel(
        facebook=social_links.facebook,
        instagram=social_links.instagram,
        linkedIn=social_links.linkedIn,
        dribble=social_links.dribble,
        profile_id=social_links.profile_id
    )
    db.add(new_social_link)
    db.commit()
    db.refresh(new_social_link)
    return new_social_link