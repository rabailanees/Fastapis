from fastapi import FastAPI
import models
from database import Base, engine
import auth_router, user_router, basicinfo_routers,edu_routers,profiles_routers,skills_routers,slinks_routers


models.Base.metadata.create_all(bind=engine)
app = FastAPI()


app.include_router(auth_router.router)
app.include_router(user_router.router)
app.include_router(basicinfo_routers.router)
app.include_router(edu_routers.router)
app.include_router(profiles_routers.router)
app.include_router(skills_routers.router)
app.include_router(slinks_routers.router)