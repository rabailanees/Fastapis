from fastapi import FastAPI, Depends, APIRouter
from sqlalchemy.orm import Session
import models, database, schemas
from sqlalchemy.orm import Session
from typing import List


app = FastAPI()


router = APIRouter(
    prefix="/basicinformation",
    tags=['Basic Information']
)


def get_basic_information(db: Session = Depends(database.get_db)):
    basic_info = db.query(models.BasicInformationModel).all()
    return basic_info


def create_basic_information(basic_info: schemas.BasicUserInformation, db: Session = Depends(database.get_db)):
    new_basic_info = models.BasicInformationModel(
        id=basic_info.id,
        date_of_birth=basic_info.date_of_birth,
        phone_number=basic_info.phone_number,
        job_title=basic_info.job_title,
        address=basic_info.address,
        gender=basic_info.gender,
        description=basic_info.description, 
        profile_id=basic_info.profile_id 
    )
    db.add(new_basic_info)
    db.commit()
    db.refresh(new_basic_info)
    return new_basic_info

@router.get('/', response_model=List[schemas.BasicUserInformation])
def get_basic_information(db: Session = Depends(database.get_db)):
    basic_info = db.query(models.BasicInformationModel).all()
    return basic_info



@router.post('/', response_model=schemas.BasicUserInformation)
def create_basic_information(basic_info: schemas.BasicUserInformation, db: Session = Depends(database.get_db)):
    new_basic_info = models.BasicInformationModel(
        date_of_birth=basic_info.date_of_birth,
        phone_number=basic_info.phone_number,
        job_title=basic_info.job_title,
        address=basic_info.address,
        gender=basic_info.gender,
        description=basic_info.description, 
        profile_id=basic_info.profile_id 
    )
    db.add(new_basic_info)
    db.commit()
    db.refresh(new_basic_info)
    return new_basic_info