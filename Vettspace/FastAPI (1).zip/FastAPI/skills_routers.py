from fastapi import Depends, FastAPI, APIRouter, HTTPException
import models, database, schemas
from sqlalchemy.orm import Session
from typing import List

app = FastAPI()

router = APIRouter(
    prefix="/skill",
    tags=['Skill']
)

def get_skills(db: Session = Depends(database.get_db)):
    skills = db.query(models.SkillModel).all()
    return skills


def create_skill(skill: schemas.Skill, db: Session = Depends(database.get_db)):
    new_skill = models.SkillModel(
        id=skill.id,
        title=skill.title,
        percentage=skill.percentage,
        profile_id=skill.profile_id  
    )
    db.add(new_skill)
    db.commit()
    db.refresh(new_skill)
    return new_skill

@router.get('/', response_model=List[schemas.Skill])
def get_skills(db: Session = Depends(database.get_db)):
    skills = db.query(models.SkillModel).all()
    return skills

@router.post('/', response_model=schemas.Skill)
def create_skill(skill: schemas.Skill, db: Session = Depends(database.get_db)):
    # Check if the profile with the given profile_id exists
    profile = db.query(models.ProfileModel).filter(models.ProfileModel.id == skill.profile_id).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    
    new_skill = models.SkillModel(
        title=skill.title,
        percentage=skill.percentage,
        profile_id=skill.profile_id
    )
    db.add(new_skill)
    db.commit()
    db.refresh(new_skill)
    return new_skill